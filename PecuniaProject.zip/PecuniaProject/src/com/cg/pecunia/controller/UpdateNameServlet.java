package com.cg.pecunia.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.pecunia.dao.AccountDAO;
import com.cg.pecunia.dao.IAccountDAO;
import com.cg.pecunia.dto.Account;

@WebServlet("/UpdateNameServlet")
public class UpdateNameServlet extends HttpServlet{
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String updatedName=request.getParameter("upName");
    IAccountDAO accountdao=new AccountDAO();
    accountdao.updateCustomerName(updatedName);
}
}
