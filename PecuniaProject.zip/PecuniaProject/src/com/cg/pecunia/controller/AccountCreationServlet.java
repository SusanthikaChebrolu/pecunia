package com.cg.pecunia.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.pecunia.dao.AccountDAO;
import com.cg.pecunia.dto.Account;
import com.cg.pecunia.exception.PecuniaException;


@WebServlet("/AccountCreationServlet")
public class AccountCreationServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		try {
			String customerName = request.getParameter("customerName");
			Long customerContactNumber = Long.parseLong(request.getParameter("customerContactNumber"));
			Long customerAdharNumber = Long.parseLong(request.getParameter("customerAadharNumber"));
			String customerPANNumber = request.getParameter("customerPANNumber");
			String customerDOB = request.getParameter("customerDOB");
			/*
			 * DateFormat format = new SimpleDateFormat("mm dd yyyy", Locale.ENGLISH); Date
			 * date;
			 */
			System.out.println(customerDOB);
			String str[] = customerDOB.split("-");
			for (int i = 0; i < str.length; i++)
				System.out.println("string array:" + str[i]);
			LocalDate date = LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]), Integer.parseInt(str[2]));
			// date = format.parse(customerDOB);

			String gender = request.getParameter("gender");
			String addLine1 = request.getParameter("addLine1");
			String addLine2 = request.getParameter("addLine2");
			String city = request.getParameter("city");
			String state = request.getParameter("state");
			String country = request.getParameter("country");

			Account account = new Account(customerName, customerContactNumber, customerAdharNumber, customerPANNumber,
					date, gender, addLine1, addLine2, city, state, country);
			AccountDAO accountDAO = new AccountDAO();
			long accNum = accountDAO.addAccount(account);
			if (accNum > 0) {
				out.println("Account created with account number " + accNum);
				response.setHeader("Refresh", "2;url=employeeHomePage.jsp");
			} else {
				out.println("Account not created!!");
			}
		} catch (PecuniaException e) {
			throw new PecuniaException("error in create account servlet" + e.getMessage());
		}
	}
}
