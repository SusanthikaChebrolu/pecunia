package com.cg.pecunia.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.pecunia.dao.AccountDAO;
import com.cg.pecunia.dto.Account;

@WebServlet("/UpdateCustomerDetailsServlet")
public class UpdateCustomerDetailsServlet extends HttpServlet{
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	Long accNo=Long.parseLong(request.getParameter("accNo"));
	Account account=new Account(accNo);
	AccountDAO accountDAO=new AccountDAO();
	boolean isAccountExist=accountDAO.accountExist(account);
	RequestDispatcher dispatcher=null;
	if(isAccountExist)
	{
		request.getRequestDispatcher("updateCustomer.jsp").include(request,response);
	}
}
}
