package com.cg.pecunia.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.pecunia.dao.LoginDAO;
import com.cg.pecunia.dto.User;
import com.cg.pecunia.exception.PecuniaException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("uname");
		String password = request.getParameter("password");
		User user = new User(username,password);
		LoginDAO loginDAO = new LoginDAO();
		RequestDispatcher dispatcher = null;
		String roleCode = loginDAO.validateLogin(user);
		//UserDTO users = loginDAO.validateLogin(user);
		System.out.println("rolecode in servlet"+roleCode);
		try {
			if(roleCode.equals("emp")) {
				request.getRequestDispatcher("employeeHomePage.jsp").forward(request, response);
				
			}else if(roleCode.equals("mngr")){
				request.getRequestDispatcher("managerHomePage.jsp").forward(request, response);
			}else {
				request.setAttribute("ErrorMsg", "User Name or Password is Invalid!");
				
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		
	} catch (PecuniaException pe) {
		throw new PecuniaException("problem in login servlet");
	}
		
	}
}
