package com.cg.pecunia.dto;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="accountsss")
public class Account {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="account_number_seq")
	@SequenceGenerator(name="account_number_seq", initialValue=102623962 )
	private Long accountNumber;
	private String customerName;
	private Long customerContactNumber;
	private Long customerAdharNumber;
	private String customerPANNumber;

	private LocalDate DOB;
	private String gender;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String country;
	private String status;
	public Account(String status) {
		super();
		this.status = status;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(Long accountNumber, String customerName, Long customerContactNumber, Long customerAdharNumber,
			String customerPANNumber, LocalDate DOB, String gender, String addressLine1, String addressLine2, String city,
			String state, String country, String status) {
		super();
		this.accountNumber = accountNumber;
		this.customerName = customerName;
		this.customerContactNumber = customerContactNumber;
		this.customerAdharNumber = customerAdharNumber;
		this.customerPANNumber = customerPANNumber;
		this.DOB = DOB;
		this.gender = gender;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.country = country;
		this.status = status;
	}
	public Account(String customerName, Long customerContactNumber, Long customerAdharNumber, String customerPANNumber,
			LocalDate DOB, String gender, String addressLine1, String addressLine2, String city, String state,
			String country) {
		super();
		this.customerName = customerName;
		this.customerContactNumber = customerContactNumber;
		this.customerAdharNumber = customerAdharNumber;
		this.customerPANNumber = customerPANNumber;
		this.DOB = DOB;
		this.gender = gender;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.city = city;
		this.state = state;
		this.country = country;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Long getCustomerContactNumber() {
		return customerContactNumber;
	}
	public void setCustomerContactNumber(Long customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}
	public Long getCustomerAdharNumber() {
		return customerAdharNumber;
	}
	public void setCustomerAdharNumber(Long customerAdharNumber) {
		this.customerAdharNumber = customerAdharNumber;
	}
	public String getCustomerPANNumber() {
		return customerPANNumber;
	}
	public void setCustomerPANNumber(String customerPANNumber) {
		this.customerPANNumber = customerPANNumber;
	}
	public LocalDate getDOB() {
		return DOB;
	}
	public void setDOB(LocalDate dOB) {
		DOB = dOB;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
