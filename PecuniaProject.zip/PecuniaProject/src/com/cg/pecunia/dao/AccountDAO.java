package com.cg.pecunia.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.pecunia.dto.Account;
import com.cg.pecunia.utility.JPAUtility;

public class AccountDAO implements IAccountDAO {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public Long addAccount(Account account) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		
		try {
			manager.persist(account);
			transaction.commit();
		} catch (PersistenceException e) {
			transaction.rollback();
			throw new PersistenceException("error in accountDAO");
			/* System.out.println(e.getMessage()); */
		} finally {
			manager.close();
			factory.close();
		}
		
		return account.getAccountNumber();
	}

	public boolean accountExist(Account account) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

		transaction.begin();

		Account accountInfo = manager.find(Account.class, account.getAccountNumber());
		System.out.println("accountInfo in dao:"+accountInfo);
		if(accountInfo!=null)
			return true;
		return false;
	}

	@Override
	public void updateCustomerName(String updatedName) {
		// TODO Auto-generated method stub
		
	}

}
