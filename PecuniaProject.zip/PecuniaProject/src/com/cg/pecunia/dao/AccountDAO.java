package com.cg.pecunia.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.pecunia.dto.Account;
import com.cg.pecunia.utility.JPAUtility;

public class AccountDAO implements IAccountDAO
{
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	@Override
	public Long addAccount(Account account) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
	    transaction=manager.getTransaction();
	    transaction.begin();
		try {
			manager.persist(account);
			transaction.commit();
		} catch (PersistenceException e) {
			transaction.rollback();
			throw new PersistenceException("error in accountDAO");
			/*System.out.println(e.getMessage());*/
		} finally {
			manager.close();
			factory.close();
		}
		return account.getAccountNumber();
	}
		
	

}
