package com.cg.pecunia.dao;

import com.cg.pecunia.dto.User;

public interface ILoginDAO {
	public String validateLogin(User user);

	
}
