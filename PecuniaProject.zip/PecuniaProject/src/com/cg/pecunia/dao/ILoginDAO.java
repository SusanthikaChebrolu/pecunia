package com.cg.pecunia.dao;

import com.cg.pecunia.dto.UserDTO;

public interface ILoginDAO {
	public String validateLogin(UserDTO user);

	
}
