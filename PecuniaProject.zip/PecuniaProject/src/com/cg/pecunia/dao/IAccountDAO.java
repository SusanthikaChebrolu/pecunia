package com.cg.pecunia.dao;

import com.cg.pecunia.dto.Account;

public interface IAccountDAO {
public Long addAccount(Account account);
}
