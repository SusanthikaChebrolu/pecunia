package com.cg.pecunia.dao;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.pecunia.dto.User;
import com.cg.pecunia.exception.PecuniaException;
import com.cg.pecunia.utility.JPAUtility;

public class LoginDAO implements ILoginDAO {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public String validateLogin(User user) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
	
		User users = null;
		try {
			
			String queryString = "SELECT us FROM User us WHERE us.username=:uname and us.password=:pwd";

			TypedQuery<User> query = manager.createQuery(queryString, User.class);
			query.setParameter("uname", user.getUsername());
			query.setParameter("pwd", user.getPassword());
			List lst = query.getResultList();
			System.out.println("list" + lst);
			Iterator it = lst.iterator();
			System.out.println("after iterator");
			while (it.hasNext()) {
				System.out.println("in while");
				users = (User) it.next();
				System.out.print("uanme:" + users.getUsername());
				System.out.print(" pwd:" + users.getPassword());
				System.out.println(" Code:" + users.getRolecode());
			}

		} catch (PecuniaException pe) {
			throw new PecuniaException("problem in validatelogin in logindao");
		}

		return users.getRolecode();

	}
}
