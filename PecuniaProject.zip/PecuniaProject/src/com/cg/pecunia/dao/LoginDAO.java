package com.cg.pecunia.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.pecunia.dto.UserDTO;
import com.cg.pecunia.exception.PecuniaException;
import com.cg.pecunia.utility.JPAUtility;

public class LoginDAO implements ILoginDAO {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public String validateLogin(UserDTO user) {

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		//List<UserDTO> users = null;
		 String roleCode = null;
		// Read the existing entries and write to console
		try {
			Query query = manager.createQuery("select u.rolecode from UserDTO u where u.username =? and u.password = ?");
			query.setParameter(1, user.getUsername());
			query.setParameter(2, user.getPassword());
			//roleCode = query.getFirstResult();
			 roleCode = (String) query.getSingleResult();
			/*String selectQuery = "select u.rolecode from UserDTO u where u.username =? and u.password = ?";
			TypedQuery<UserDTO> query = manager.createQuery(selectQuery, UserDTO.class);
			query.setParameter(1, user.getUsername());
			query.setParameter(2, user.getPassword());
			users = query.getResultList();*/

		} catch (PecuniaException pe) {
			throw new PecuniaException("problem in validatelogin in logindao");
		}
		System.out.println("rolecode in dao"+roleCode);
		return roleCode;

	}
}
