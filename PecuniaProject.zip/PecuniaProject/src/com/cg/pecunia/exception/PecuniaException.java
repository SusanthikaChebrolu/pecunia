package com.cg.pecunia.exception;

public class PecuniaException extends RuntimeException {
	public PecuniaException(String message) {
		super(message);
	}
}
